#!/usr/bin/env python3
"""Convert WeChat and Alipay bill exports into a privacy-safe spending report."""

import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path

import pandas as pd


GROUPS = ["住房", "学习", "购物", "吃喝", "出行", "家人", "人情", "健康", "旅行", "其他"]
VALUES = ["必要", "积累", "享受", "给别人"]

GROUP_BY_CAT = {
    "住房": "住房",
    "学习": "学习",
    "买买买": "购物",
    "出行": "出行",
    "旅行住宿": "旅行",
    "吃饭": "吃喝",
    "外卖": "吃喝",
    "超市生鲜": "吃喝",
    "咖啡茶饮": "吃喝",
    "人情往来": "家人",
    "朋友人情": "人情",
    "待确认转账": "其他",
    "健身": "健康",
    "医疗": "健康",
    "自我投资": "学习",
    "数字订阅": "其他",
    "通讯": "其他",
    "充电宝": "其他",
    "其他": "其他",
}
VALUE_BY_CAT = {
    "住房": "必要",
    "吃饭": "必要",
    "超市生鲜": "必要",
    "外卖": "必要",
    "出行": "必要",
    "通讯": "必要",
    "医疗": "必要",
    "充电宝": "必要",
    "学习": "积累",
    "自我投资": "积累",
    "健身": "积累",
    "数字订阅": "积累",
    "买买买": "享受",
    "咖啡茶饮": "享受",
    "旅行住宿": "享受",
    "其他": "享受",
    "人情往来": "给别人",
    "朋友人情": "给别人",
    "待确认转账": "给别人",
}
WECHAT_COLUMNS = {
    "交易时间", "交易类型", "交易对方", "商品", "收/支", "金额(元)", "当前状态",
}
ALIPAY_COLUMNS = {
    "交易时间", "交易分类", "交易对方", "商品说明", "收/支", "金额", "交易状态",
    "交易订单号",
}
ALIPAY_CATEGORY_MAP = {
    "交通出行": "出行",
    "服饰装扮": "买买买",
    "美容美发": "买买买",
    "日用百货": "超市生鲜",
    "餐饮美食": "吃饭",
    "住房物业": "住房",
    "医疗健康": "医疗",
    "教育培训": "自我投资",
    "家居家装": "买买买",
    "数码电器": "买买买",
    "生活服务": "其他",
    "文化休闲": "其他",
    "充值缴费": "通讯",
    "商业服务": "其他",
    "其他": "其他",
}

# Generic terms and widely used platforms only; no account-specific merchants.
RULES = [
    ("外卖", re.compile(r"外卖|饿了么|美团外卖|Foodpanda", re.IGNORECASE)),
    ("超市生鲜", re.compile(
        r"盒马|朴朴|山姆|沃尔玛|Walmart|永辉|全家|罗森|Lawson|7-?Eleven|"
        r"美宜佳|超市|便利店|叮咚买菜|京东到家",
        re.IGNORECASE,
    )),
    ("咖啡茶饮", re.compile(
        r"咖啡|奶茶|茶饮|星巴克|霸王茶姬|古茗|瑞幸|Luckin|Cotti|Peet'?s",
        re.IGNORECASE,
    )),
    ("旅行住宿", re.compile(
        r"酒店|民宿|机票|航空|携程|同程|飞猪|Trip\.com|旅行|旅游",
        re.IGNORECASE,
    )),
    ("出行", re.compile(
        r"滴滴|高德打车|打车|车费|停车|通行费|地铁|公交|12306|哈啰|HelloRide|"
        r"交通出行",
        re.IGNORECASE,
    )),
    ("健身", re.compile(r"健身|Fitness|健身房", re.IGNORECASE)),
    ("充电宝", re.compile(r"充电宝|小电|怪兽充电|搜电|街电", re.IGNORECASE)),
    ("数字订阅", re.compile(
        r"Apple|App Store|iCloud|腾讯云|软件订阅|会员订阅|视频会员",
        re.IGNORECASE,
    )),
    ("通讯", re.compile(r"联通|移动|电信|话费|手机充值|交费", re.IGNORECASE)),
    ("医疗", re.compile(r"医院|药房|药店|药品|诊所|医疗健康", re.IGNORECASE)),
    ("买买买", re.compile(
        r"京东|淘宝|天猫|拼多多|抖音电商|抖音商城|小红书|转转|名创优品|"
        r"优衣库|服装|服饰|购物",
        re.IGNORECASE,
    )),
    ("吃饭", re.compile(
        r"餐|饭|火锅|烧烤|海鲜|龙虾|粥|面|汤包|麦当劳|肯德基|必胜客|"
        r"汉堡王|海底捞|大众点评|美团",
        re.IGNORECASE,
    )),
]

HOUSING_RE = re.compile(r"房租|租金|物业|自如|链家|贝壳|公寓", re.IGNORECASE)
BEAUTY_RE = re.compile(
    r"医疗美容|医美|整形|纹绣|美容|美甲|美睫|美发|造型|塑身|SPA",
    re.IGNORECASE,
)
EDUCATION_RE = re.compile(r"教育|课程|培训|知识|得到|Kindle|书", re.IGNORECASE)
BOOK_RE = re.compile(r"Kindle|书", re.IGNORECASE)
INTERNAL_MOVE_RE = re.compile(r"零钱提现|零钱通|理财", re.IGNORECASE)
TAXI_RE = re.compile(r"滴滴|高德打车|师傅|打车", re.IGNORECASE)
PARTIAL_REFUND_RE = re.compile(r"已退款\s*[（(]?\s*[¥￥]?\s*([\d,，.]+)")
MONEY_RE = re.compile(r"[-+]?\d[\d,，]*(?:\.\d+)?")
SOCIAL_TRANSFER_RE = re.compile(r"群收款|AA|拼单")
KIN_RE = re.compile(
    r"妈|爸|母亲|父亲|爷|奶|外公|外婆|姥|舅|姨|姑|叔|伯|哥|姐|弟|妹|"
    r"老公|老婆|媳妇|丈夫|妻子|儿子|女儿|家"
)
TRANSFER_LABELS = {"家人", "人情", "房租", "其他消费", "不算"}

DAY_BANDS = [
    (0, 0.01, "0"),
    (0.01, 50, "<50"),
    (50, 200, "50–200"),
    (200, 500, "200–500"),
    (500, 2_000, "500–2k"),
    (2_000, float("inf"), "≥2k"),
]
TX_BANDS = [
    (0, 30, "<30"),
    (30, 100, "30–100"),
    (100, 500, "100–500"),
    (500, 1_000, "500–1k"),
    (1_000, 5_000, "1k–5k"),
    (5_000, float("inf"), "≥5k"),
]


def cell_text(value):
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    return str(value).strip()


def read_tables(path):
    path = Path(path)
    if path.suffix.lower() in {".xlsx", ".xlsm"}:
        sheets = pd.read_excel(
            path, sheet_name=None, header=None, dtype=object, engine="openpyxl"
        )
        return list(sheets.values())
    errors = []
    for encoding in ("utf-8-sig", "utf-8", "gbk"):
        try:
            with path.open(encoding=encoding, newline="") as source:
                rows = list(csv.reader(source))
            return [pd.DataFrame(rows, dtype=object)]
        except (UnicodeDecodeError, LookupError, csv.Error) as error:
            errors.append(error)
    raise ValueError(f"Could not read CSV using UTF-8 or GBK: {path}") from errors[-1]


def export_kind(header):
    columns = set(header)
    if WECHAT_COLUMNS.issubset(columns):
        return "wechat"
    if ALIPAY_COLUMNS.issubset(columns):
        return "alipay"
    return None


def parse_date(value):
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime.combine(value, datetime.min.time())
    try:
        parsed = pd.to_datetime(value, errors="coerce")
    except (TypeError, ValueError, OverflowError):
        return None
    if pd.isna(parsed):
        return None
    if getattr(parsed, "tzinfo", None) is not None:
        parsed = parsed.tz_localize(None)
    return parsed.to_pydatetime()


def parse_money(value):
    text = cell_text(value).replace("¥", "").replace("￥", "").replace("元", "")
    match = MONEY_RE.search(text)
    if not match:
        return None
    return abs(round(float(match.group(0).replace(",", "").replace("，", ""))))


def read_exports(paths):
    records = []
    raw_count = 0
    for path in paths:
        found_header = False
        for table in read_tables(path):
            header_index = None
            header = None
            kind = None
            for index in range(len(table)):
                candidate = [cell_text(value).lstrip("\ufeff") for value in table.iloc[index].tolist()]
                if not candidate or not candidate[0].startswith("交易时间"):
                    continue
                detected_kind = export_kind(candidate)
                if detected_kind:
                    header_index, header, kind = index, candidate, detected_kind
                    break
            if header_index is None:
                continue

            found_header = True
            column_indexes = {name: header.index(name) for name in header if name}
            for values in table.iloc[header_index + 1:].itertuples(index=False, name=None):
                timestamp_text = cell_text(values[column_indexes["交易时间"]])
                if not timestamp_text:
                    continue
                raw_count += 1
                if kind == "wechat":
                    records.append({
                        "source": kind,
                        "time": parse_date(values[column_indexes["交易时间"]]),
                        "type": cell_text(values[column_indexes["交易类型"]]),
                        "party": cell_text(values[column_indexes["交易对方"]]),
                        "description": cell_text(values[column_indexes["商品"]]),
                        "direction": cell_text(values[column_indexes["收/支"]]),
                        "amount": parse_money(values[column_indexes["金额(元)"]]),
                        "status": cell_text(values[column_indexes["当前状态"]]),
                        "category": "",
                        "order": "",
                    })
                else:
                    records.append({
                        "source": kind,
                        "time": parse_date(values[column_indexes["交易时间"]]),
                        "type": "",
                        "party": cell_text(values[column_indexes["交易对方"]]),
                        "description": cell_text(values[column_indexes["商品说明"]]),
                        "direction": cell_text(values[column_indexes["收/支"]]),
                        "amount": parse_money(values[column_indexes["金额"]]),
                        "status": cell_text(values[column_indexes["交易状态"]]),
                        "category": cell_text(values[column_indexes["交易分类"]]),
                        "order": cell_text(values[column_indexes["交易订单号"]]),
                    })
        if not found_header:
            raise ValueError(f"No supported WeChat or Alipay bill header found: {path}")
    return records, raw_count


def order_prefix(order):
    text = cell_text(order)
    return text.split("_", 1)[0] if text else ""


def is_closed(record):
    return record["source"] == "alipay" and record["status"] == "交易关闭"


def alipay_refunds(records):
    by_order = defaultdict(int)
    total = 0
    for record in records:
        if record["source"] != "alipay" or record["category"] != "退款" or is_closed(record):
            continue
        amount = record["amount"] or 0
        total += amount
        prefix = order_prefix(record["order"])
        if prefix:
            by_order[prefix] += amount
    return by_order, total


def wechat_refund(status, amount):
    if status in {"已全额退款", "对方已退还"}:
        return amount
    match = PARTIAL_REFUND_RE.search(status)
    if not match:
        return 0
    return parse_money(match.group(1)) or 0


def categorize(record, text):
    source_category = record["category"]
    if source_category == "住房物业" or HOUSING_RE.search(text):
        return "住房"
    if BEAUTY_RE.search(text) or source_category == "美容美发":
        return "买买买"
    if source_category == "教育培训":
        return "自我投资"
    if EDUCATION_RE.search(text):
        return "学习" if BOOK_RE.search(text) else "自我投资"
    for category, pattern in RULES:
        if pattern.search(text):
            return category
    return ALIPAY_CATEGORY_MAP.get(source_category, "其他")


def transfer_kind(record):
    if record["source"] == "wechat":
        return record["type"] in {"转账", "微信红包"}
    return record["category"] == "转账红包"


def nth_weekday(year, month, weekday, occurrence):
    first = date(year, month, 1)
    first_match = 1 + (weekday - first.weekday()) % 7
    return date(year, month, first_match + 7 * (occurrence - 1))


def event_reason(day, amount):
    if day == nth_weekday(day.year, 5, 6, 2):
        return "母亲节转账"
    if day == nth_weekday(day.year, 6, 6, 3):
        return "父亲节转账"
    if (day.month == 1 and day.day >= 20) or (day.month == 2 and day.day <= 20):
        return "春节转账"
    if amount == 520:
        return "520心意转账"
    if amount == 1314:
        return "1314心意转账"
    return ""


def normalize_labels(labels):
    if labels is None:
        return {}
    if not isinstance(labels, dict):
        raise ValueError("labels must be a mapping of payee names to transfer labels.")
    for payee, label in labels.items():
        if not isinstance(payee, str) or not isinstance(label, str) or label not in TRANSFER_LABELS:
            raise ValueError(f"Invalid transfer label for payee: {payee!r}")
    return labels


def auto_transfer_label(record, text, gross):
    if SOCIAL_TRANSFER_RE.search(text):
        return "人情"
    if KIN_RE.search(" ".join((record["party"], record["description"]))):
        return "家人"
    if event_reason(record["time"].date(), gross):
        return "家人"
    if record["source"] == "wechat" and record["type"] == "微信红包":
        return "人情"
    return "待确认"


def month_range(start, end):
    year, month = start.year, start.month
    months = []
    while (year, month) <= (end.year, end.month):
        months.append(f"{year:04d}-{month:02d}")
        if month == 12:
            year, month = year + 1, 1
        else:
            month += 1
    return months


def summarize(records, all_records, raw_count, raw_out, refund, moves, transfers, labels):
    spend = [row for row in records if row.get("cat") and row["amount"] > 0]
    all_dates = [row["time"].date() for row in all_records if row["time"] is not None]
    if not all_dates:
        raise ValueError("No dated transaction rows were found in the exports.")

    start_date, end_date = min(all_dates), max(all_dates)
    span = (end_date - start_date).days + 1
    dates = [start_date + timedelta(days=index) for index in range(span)]
    months = month_range(start_date, end_date)
    total = sum(row["amount"] for row in spend)
    nonrent_rows = [row for row in spend if row["cat"] != "住房"]
    nonrent_total = sum(row["amount"] for row in nonrent_rows)
    rent_total = sum(row["amount"] for row in spend if row["cat"] == "住房")

    by_group = defaultdict(list)
    by_value = defaultdict(list)
    for row in spend:
        by_group[GROUP_BY_CAT[row["cat"]]].append(row)
        by_value[VALUE_BY_CAT[row["cat"]]].append(row)

    cats = []
    for group in GROUPS:
        rows = by_group[group]
        sub_totals = defaultdict(int)
        for row in rows:
            sub_totals[row["cat"]] += row["amount"]
        sub = {
            category: amount
            for category, amount in sorted(sub_totals.items(), key=lambda item: (-item[1], item[0]))
        }
        cats.append({
            "k": group,
            "v": sum(row["amount"] for row in rows),
            "n": len(rows),
            "val": VALUE_BY_CAT[rows[0]["cat"]] if rows else "",
            "sub": sub,
        })

    values = []
    for value in VALUES:
        rows = by_value[value]
        sub_totals = defaultdict(int)
        for row in rows:
            sub_totals[row["cat"]] += row["amount"]
        sub = {
            category: amount
            for category, amount in sorted(sub_totals.items(), key=lambda item: (-item[1], item[0]))
        }
        values.append({
            "k": value,
            "v": sum(row["amount"] for row in rows),
            "n": len(rows),
            "pd": round(sum(row["amount"] for row in rows) / span),
            "sub": sub,
        })

    daily_amounts = [0] * span
    daily_counts = [0] * span
    daily_groups = [defaultdict(int) for _ in range(span)]
    heat_n = [[0 for _ in range(24)] for _ in range(7)]
    heat_s = [[0 for _ in range(24)] for _ in range(7)]
    dom = [0] * 31
    weekday_spend = [0] * 7
    for row in spend:
        weekday = row["time"].weekday()
        hour = row["time"].hour
        heat_n[weekday][hour] += 1
        if row["cat"] == "住房":
            continue
        index = (row["time"].date() - start_date).days
        group = GROUP_BY_CAT[row["cat"]]
        daily_amounts[index] += row["amount"]
        daily_counts[index] += 1
        daily_groups[index][group] += row["amount"]
        heat_s[weekday][hour] += row["amount"]
        dom[row["time"].day - 1] += row["amount"]
        weekday_spend[weekday] += row["amount"]

    daily = []
    for index in range(span):
        groups = daily_groups[index]
        largest_group = max(groups, key=lambda group: (groups[group], group)) if groups else ""
        daily.append([daily_amounts[index], daily_counts[index], largest_group])

    top_indices = sorted(range(span), key=lambda index: (-daily_amounts[index], index))[:5]
    if top_indices:
        while len(top_indices) < 5:
            top_indices.append(top_indices[-1])
    top = [
        {
            "d": dates[index].strftime("%m.%d"),
            "v": daily_amounts[index],
            "g": daily[index][2],
        }
        for index in top_indices
    ]

    dd = []
    for low, high, label in DAY_BANDS:
        selected = [amount for amount in daily_amounts if low <= amount < high]
        dd.append({"k": label, "n": len(selected), "v": sum(selected)})

    band = []
    for low, high, label in TX_BANDS:
        selected = [row["amount"] for row in nonrent_rows if low <= row["amount"] < high]
        band.append({"k": label, "n": len(selected), "v": sum(selected)})

    sorted_values = sorted((row["amount"] for row in nonrent_rows), reverse=True)
    if nonrent_total:
        running = 0
        running_shares = []
        for amount in sorted_values:
            running += amount
            running_shares.append(running / nonrent_total)
        pareto = [
            round(running_shares[max(0, int(len(sorted_values) * pct / 100) - 1)], 4)
            for pct in range(1, 101)
        ]
    else:
        pareto = [0.0] * 99 + [1.0]

    cumulative = []
    running = 0
    for amount in daily_amounts:
        running += amount
        cumulative.append(running)
    cumd = [cumulative[index] for index in range(0, span, 3)]
    bigs = [
        {
            "i": (row["time"].date() - start_date).days,
            "v": row["amount"],
            "g": GROUP_BY_CAT[row["cat"]],
        }
        for row in sorted(nonrent_rows, key=lambda item: item["time"])
        if row["amount"] >= 1_000
    ]

    month_rows = []
    for month in months:
        rows = [row for row in spend if row["time"].strftime("%Y-%m") == month]
        group_totals = defaultdict(int)
        value_totals = defaultdict(int)
        for row in rows:
            group_totals[GROUP_BY_CAT[row["cat"]]] += row["amount"]
            value_totals[VALUE_BY_CAT[row["cat"]]] += row["amount"]
        month_rows.append({
            "m": month,
            "v": sum(row["amount"] for row in rows),
            "nh": sum(row["amount"] for row in rows if row["cat"] != "住房"),
            "g": dict(sorted(group_totals.items())),
            "val": dict(sorted(value_totals.items())),
        })

    family_small_rows = [row for row in spend if row["cat"] == "人情往来"]
    family_small = sum(row["amount"] for row in family_small_rows)
    fmon = {month: 0 for month in months}
    for row in family_small_rows:
        fmon[row["time"].strftime("%Y-%m")] += row["amount"]
    family_transfers = [transfer for transfer in transfers if transfer["label"] == "家人"]
    family_big = 0
    family_big_count = 0
    for transfer in family_transfers:
        if transfer["big"]:
            family_big += transfer["amount"]
            family_big_count += 1
            month = transfer["time"].strftime("%Y-%m")
            if month in fmon:
                fmon[month] += transfer["amount"]
    family_n = len(family_small_rows) + family_big_count

    events = []
    seen_events = set()
    for transfer in sorted(family_transfers, key=lambda row: row["time"]):
        day = transfer["time"].date()
        reason = event_reason(day, transfer["gross"])
        key = (day, reason)
        if reason and key not in seen_events:
            events.append([day.strftime("%m.%d"), reason])
            seen_events.add(key)
        if len(events) == 4:
            break

    taxi_rows = [row for row in nonrent_rows if TAXI_RE.search(row["text"])]
    night_rows = [row for row in spend if row["time"].hour < 5]
    active_days = len({row["time"].date() for row in spend})
    weekday_counts = [sum(day.weekday() == weekday for day in dates) for weekday in range(7)]
    weekday_avg = round(sum(weekday_spend[:5]) / sum(weekday_counts[:5])) if sum(weekday_counts[:5]) else 0
    weekend_avg = round(sum(weekday_spend[5:]) / sum(weekday_counts[5:])) if sum(weekday_counts[5:]) else 0
    top10_count = int(span * 0.1)
    top10 = (
        sum(sorted(daily_amounts, reverse=True)[:top10_count]) / nonrent_total
        if nonrent_total and top10_count
        else 0.0
    )
    nonrent_transaction_values = [row["amount"] for row in nonrent_rows]
    top_bills = [
        {
            "d": row["time"].strftime("%m.%d"),
            "v": row["amount"],
            "g": GROUP_BY_CAT[row["cat"]],
            "t": {
                "买买买": "购物",
                "人情往来": "家人",
                "待确认转账": "转账(待确认)",
            }.get(row["cat"], row["cat"]),
        }
        for row in sorted(nonrent_rows, key=lambda row: (-row["amount"], row["time"]))[:10]
    ]
    payee_rows = defaultdict(list)
    for transfer in transfers:
        payee_rows[transfer["payee"]].append(transfer)
    payees = []
    for payee, payee_transfers in payee_rows.items():
        auto_counts = Counter(transfer["auto"] for transfer in payee_transfers)
        first_auto = {}
        for index, transfer in enumerate(payee_transfers):
            first_auto.setdefault(transfer["auto"], index)
        auto = max(auto_counts, key=lambda label: (auto_counts[label], -first_auto[label]))
        payees.append({
            "name": payee,
            "n": len(payee_transfers),
            "v": sum(transfer["gross"] for transfer in payee_transfers),
            "auto": auto,
            "label": labels.get(payee, auto),
        })
    payees = sorted(payees, key=lambda item: (-item["v"], item["name"]))[:10]
    social_small = sum(row["amount"] for row in spend if row["cat"] == "朋友人情")
    pending_small = sum(row["amount"] for row in spend if row["cat"] == "待确认转账")
    fam_big_sum = sum(
        transfer["amount"]
        for transfer in transfers
        if transfer["big"] and transfer["label"] == "家人"
    )
    social_big_sum = sum(
        transfer["amount"]
        for transfer in transfers
        if transfer["big"] and transfer["label"] == "人情"
    )
    pending_big_sum = sum(
        transfer["amount"]
        for transfer in transfers
        if transfer["big"] and transfer["label"] == "待确认"
    )

    return {
        "period": f"{start_date:%Y.%m.%d} — {end_date:%Y.%m.%d}",
        "total": total,
        "n": len(spend),
        "days": active_days,
        "span": span,
        "per_month": round(total / 12),
        "per_day": round(total / span),
        "per_day_nh": round(nonrent_total / span),
        "median_day": round(float(pd.Series(daily_amounts).median())),
        "top10": round(top10, 3),
        "median": round(float(pd.Series(nonrent_transaction_values).median()), 1) if nonrent_transaction_values else 0.0,
        "raw_out": raw_out,
        "refund": refund,
        "moves": moves,
        "xfer": {
            "fam": family_small,
            "fam_big": fam_big_sum,
            "social": social_small,
            "social_big": social_big_sum,
            "pending": pending_small,
            "pending_big": pending_big_sum,
            "n_pending": sum(transfer["label"] == "待确认" for transfer in transfers),
            "labeled": bool(labels),
        },
        "payees": payees,
        "top_bills": top_bills,
        "big_n": len(bigs),
        "big_v": sum(row["amount"] for row in nonrent_rows if row["amount"] >= 1_000),
        "nh_total": nonrent_total,
        "cats": cats,
        "val": values,
        "nec_pd": round(sum(row["amount"] for row in spend if VALUE_BY_CAT[row["cat"]] == "必要") / span),
        "nec_nh_pd": round(sum(row["amount"] for row in nonrent_rows if VALUE_BY_CAT[row["cat"]] == "必要") / span),
        "rent_pd": round(rent_total / span),
        "mon": month_rows,
        "heat_n": heat_n,
        "heat_s": heat_s,
        "daily": daily,
        "top": top,
        "dd": dd,
        "band": band,
        "pareto": pareto,
        "cumd": cumd,
        "bigs": bigs,
        "dom": dom,
        "wd_s": weekday_spend,
        "hab": [
            {"k": "打车", "n": len(taxi_rows), "v": sum(row["amount"] for row in taxi_rows)},
            {"k": "外卖", "n": sum(row["cat"] == "外卖" for row in nonrent_rows), "v": sum(row["amount"] for row in nonrent_rows if row["cat"] == "外卖")},
            {"k": "数字订阅", "n": sum(row["cat"] == "数字订阅" for row in nonrent_rows), "v": sum(row["amount"] for row in nonrent_rows if row["cat"] == "数字订阅")},
            {"k": "共享充电宝", "n": sum(row["cat"] == "充电宝" for row in nonrent_rows), "v": sum(row["amount"] for row in nonrent_rows if row["cat"] == "充电宝")},
            {"k": "咖啡茶饮", "n": sum(row["cat"] == "咖啡茶饮" for row in nonrent_rows), "v": sum(row["amount"] for row in nonrent_rows if row["cat"] == "咖啡茶饮")},
            {"k": "健身", "n": sum(row["cat"] == "健身" for row in nonrent_rows), "v": sum(row["amount"] for row in nonrent_rows if row["cat"] == "健身")},
        ],
        "rel": {
            "self": sum(row["amount"] for row in spend if VALUE_BY_CAT[row["cat"]] in {"积累", "享受"}),
            "life": sum(row["amount"] for row in spend if VALUE_BY_CAT[row["cat"]] == "必要"),
            "fam_small": family_small,
            "fam_big": family_big,
            "fam_n": family_n,
            "f520": sum(transfer["gross"] == 520 for transfer in family_transfers),
            "fmon": fmon,
            "events": events,
            "who": "家人",
        },
        "night_n": len(night_rows),
        "night_s": sum(row["amount"] for row in night_rows),
        "night_buy": sum(GROUP_BY_CAT[row["cat"]] == "购物" for row in night_rows),
        "zero_days": daily_amounts.count(0),
        "weekday_avg": weekday_avg,
        "weekend_avg": weekend_avg,
        "records": raw_count,
    }


def build_report(paths, labels=None):
    labels = normalize_labels(labels)
    records, raw_count = read_exports(paths)
    refund_by_order, refund_total = alipay_refunds(records)
    spend_records = []
    raw_out = 0
    moves = 0
    transfers = []

    for record in records:
        if record["time"] is None or is_closed(record):
            continue
        if record["source"] == "alipay" and record["category"] == "退款":
            continue
        if record["direction"] != "支出" or record["amount"] is None:
            continue

        gross = record["amount"]
        raw_out += gross
        if record["source"] == "wechat":
            refunded = wechat_refund(record["status"], gross)
            refund_total += refunded
        else:
            prefix = order_prefix(record["order"])
            refunded = refund_by_order.get(prefix, 0) if prefix else 0
        net = max(0, gross - refunded)
        if net == 0:
            continue

        text = " ".join(
            part
            for part in (
                record["party"], record["description"], record["type"], record["category"]
            )
            if part
        )
        if INTERNAL_MOVE_RE.search(text):
            moves += net
            continue

        if record["source"] == "alipay" and record["category"] == "信用借还":
            moves += net
            continue

        is_transfer = transfer_kind(record) or SOCIAL_TRANSFER_RE.search(text)
        if is_transfer:
            is_big = gross >= 1_000
            payee = record["party"].strip() or "（无昵称）"
            auto_label = auto_transfer_label(record, text, gross)
            label = labels.get(payee, auto_label)
            transfer = {
                "time": record["time"],
                "amount": net,
                "gross": gross,
                "big": is_big,
                "payee": payee,
                "auto": auto_label,
                "label": label,
            }
            transfers.append(transfer)
            if label == "房租":
                category = "住房"
            elif label == "其他消费":
                category = "其他"
            elif label == "不算":
                moves += net
                continue
            elif is_big:
                moves += net
                continue
            elif label == "家人":
                category = "人情往来"
            elif label == "人情":
                category = "朋友人情"
            else:
                category = "待确认转账"
        else:
            category = categorize(record, text)

        spend_records.append({
            "time": record["time"],
            "amount": net,
            "cat": category,
            "text": text,
        })

    return summarize(
        spend_records, records, raw_count, raw_out, refund_total, moves, transfers, labels
    )


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Build a spending report from WeChat and Alipay CSV/XLSX exports."
    )
    parser.add_argument("files", nargs="+", help="one or more WeChat or Alipay bill exports")
    parser.add_argument("-o", "--output", required=True, help="destination JSON file")
    parser.add_argument("--labels", help="JSON file mapping payees to transfer labels")
    args = parser.parse_args(argv)

    labels = {}
    if args.labels:
        with Path(args.labels).open(encoding="utf-8") as source:
            labels = json.load(source)
    report = build_report(args.files, labels=labels)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as destination:
        json.dump(report, destination, ensure_ascii=False, indent=2)
        destination.write("\n")
    print(f"Wrote report JSON: {output}")


if __name__ == "__main__":
    main()
